import React, { useState, useEffect } from 'react';
import { BrowserRouter, Route, Routes, Link, useLocation } from 'react-router-dom';
import axios from 'axios';
import Header from './components/Header';
import UserMenu from './components/UserMenu';
import MapComponent from './components/MapComponent';
import Compass from './components/Compass';
import DashboardOverview from './components/DashboardOverview';
import HistoricalPage from './components/HistoricalPage';
import BatteryStatus from './components/BatteryStatus';
import SpeedChart from './components/SpeedChart';
import WavesChart from './components/WavesChart';
import WindSpeedChart from './components/WindSpeedChart';
import './App.css';

const App = () => {
  const location = useLocation();
  const [selectedChart, setSelectedChart] = useState(null);
  const [data, setData] = useState(null);
  const [batteryHistory, setBatteryHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await axios.get('http://localhost:5000/dados');
        if (res.data && res.data.length > 0) {
          const latestData = res.data[res.data.length - 1];
          setData({
            battery: latestData.Volt ?? 0,
            windSpeed: latestData.Current ?? 0,
            motorSpeed: latestData.Motor_Speed_RPM ?? 0,
            motorTemp: latestData.Motor_Temp_C ?? 0,
            controlTemp: latestData.Ctrl_Temp_C ?? 0,
            speedKph: latestData.Speed_KPH ?? 0,
          });

          setBatteryHistory(prev => {
            const newHistory = [...prev.slice(-19), latestData.Volt ?? 0]; // mantém último 20 pontos
            return newHistory;
          });
        } else {
          setError('Nenhum dado recebido do servidor');
          setData(null);
        }
      } catch (err) {
        setError('Erro ao buscar dados: ' + err.message);
        setData(null);
      }
      setLoading(false);
    };

    fetchData();

    const interval = setInterval(fetchData, 5000); // atualiza a cada 5s

    return () => clearInterval(interval);
  }, []);

  const renderSelectedChartContent = () => {
  if (loading) return <div>Carregando dados...</div>;
  if (error) return <div style={{ color: 'red' }}>Erro: {error}</div>;
  if (!data) return <div>Nenhum dado disponível</div>;

  switch (selectedChart) {
    case 'battery':
      return <BatteryStatus percentage={data.battery} historyData={batteryHistory} />;
    case 'speed':
      return <SpeedChart data={Array.isArray(data.windSpeed) ? data.windSpeed : [data.windSpeed]} />;
    case 'waves':
      return <WavesChart data={Array.isArray(data.windSpeed) ? data.windSpeed : [data.windSpeed]} />;
    case 'windSpeed':
      return <WindSpeedChart data={data.windSpeed} />;
    case 'navigation':
      return <Compass />;
    case 'climate':
      return (
        <div style={{ color: "var(--text-primary)", fontSize: "24px" }}>
          Clima: {Math.floor(data.climate)}°C
        </div>
      );
    default:
      return (
        <div style={{ color: "var(--text-secondary)", fontSize: "18px" }}>
          Selecione um indicador no menu para visualizar o gráfico.
        </div>
      );
  }
};

  return (
    <div className="app-container">
      <Header />
      <div className="menu-container">
        {(location.pathname === '/historico' || location.pathname === '/configuracao') && (
          <Link to="/" className="menu" style={{ marginBottom: '10px' }}>
            Voltar ao Início
          </Link>
        )}

        <UserMenu />

        {location.pathname !== '/historico' && location.pathname !== '/configuracao' && (
          <>
            <button className="menu" onClick={() => setSelectedChart('battery')}>
              Status da Bateria
            </button>
            <button className="menu" onClick={() => setSelectedChart('speed')}>
              Velocidade do Barco
            </button>
            <button className="menu" onClick={() => setSelectedChart('motorSpeed')}>
              Velocidade do Motor
            </button>
            <button className="menu" onClick={() => setSelectedChart('motorTemp')}>
              Temperatura do Motor
            </button>
            <button className="menu" onClick={() => setSelectedChart('controlTemp')}>
              Temperatura do Controle
            </button>
            <button className="menu" onClick={() => setSelectedChart('windSpeed')}>
              Velocidade do Vento
            </button>
            <button className="menu" onClick={() => setSelectedChart('navigation')}>
              Navegação
            </button>
          </>
        )}
      </div>

      <Routes>
        <Route
          path="/"
          element={
          <div className="content">
            <div className="map-container">
              <MapComponent />
            </div>
              <div className="grafico-container">{renderSelectedChartContent()}</div>
            </div>
          }
        />
        <Route path="/historico" element={<HistoricalPage />} />
        <Route path="/configuracao" element={<DashboardOverview />} />
      </Routes>
    </div>
  );
};

export default () => (
  <BrowserRouter>
    <App />
  </BrowserRouter>
);
